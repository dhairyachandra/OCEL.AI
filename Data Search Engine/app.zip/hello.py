from os.path import sep

from flask import Flask, request, render_template
from kaggle.api.kaggle_api_extended import KaggleApi
import requests
import random
import json


app = Flask(__name__, template_folder='templates')

@app.route('/')
def my_form():
    #return "Hello World"
    return render_template('data.html')

@app.route('/', methods=['POST'])
def my_form_post():
    api = KaggleApi()
    print('Hello')
    api.authenticate()
    text = request.form['text']
    print(text)
    datasets = api.dataset_list(search=text)
    response = requests.get('http://catalog.data.gov/api/3/action/package_search?q=' +text+ '&rows=50')
    response_dict = json.loads(response.content)
    print(response_dict)
    dataset = list()
    for dat in datasets:
        dataset.append({'name':dat.title,
            'source':'Kaggle',
            'size':dat.size,
            'alternateName':dat.subtitle,
            'url':dat.url,
            'tags':dat.tags,
            'contentUrl':'https://www.kaggle.com/'+dat.ref+'/download'})

    for res in response_dict['result']['results']:
        tags = []
        for tag in res['tags']:
            tags.append(tag['name'])
        try:
            contentUrl=res['resources'][0]['url']
        except:
            contentUrl='empty'
        dataset.append({'name':res['title'],
        'source':"Data.Gov",
        'size':None,
        'alternateName':res['notes'],
        'url':'https://catalog.data.gov/dataset/' + res['name'],
        'tags':tags,
        'contentUrl':contentUrl})


    random.shuffle(dataset)
    return  render_template('data.html', datasetInfo=dataset, value=text)

if __name__ == '__main__':
    app.run()
